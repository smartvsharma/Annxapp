module.exports = function(app, express, passport) {
	var router = express.Router();

	var userObj = require('./../app/controllers/users/users.js');
	var wishlistObj = require('./../app/controllers/users/wishlist.js');

		router.post('/authenticate', passport.authenticate('userLogin', {failureRedirect: '/users/loginFailure'}), userObj.authenticate);
		router.post('/authenticateSocial',userObj.facebookcheck);
		router.get('/list', userObj.list);
		router.post('/add', passport.authenticate('basic', {session:false}), userObj.add);
		router.param('id', userObj.user);
		router.post('/update/:id', passport.authenticate('basic', {session:false}), userObj.update);
		router.get('/loginFailure', userObj.failureRedirect);
		router.post('/bulkUpdate', userObj.bulkUpdate);
        router.post('/signupUser',userObj.signupUser);
		
        router.post('/userWishlist',wishlistObj.addwishlist);
        router.get('/showWishlist',wishlistObj.showwishlist);
		
        router.post('/forgot_password', userObj.forgot_password);
		router.post('/reset_password', userObj.reset_password);
		router.get('/viewUser',userObj.viewUser);
		router.post('/edituserprofile/',userObj.edituserprofile);
		router.post('/logOut',userObj.LogOut);
		router.post('/editprofile',userObj.editProfile);
		router.post('/search',userObj.search);
		app.use('/users', router);
        
// {failureRedirect: '/users/loginFailure'}
}
